Use Facturas

DBCC CHECKIDENT (Seg_Cliente, RESEED, 0)

TRUNCATE TABLE Seg_Cliente

DROP TABLE Seg_Cliente