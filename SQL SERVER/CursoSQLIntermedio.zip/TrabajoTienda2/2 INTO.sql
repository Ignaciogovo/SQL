Use Facturas

declare @dni varchar(14)

set @dni = '111111111B'

/*
select * 
into Seg_Cliente
from Cliente
where dni like @dni
*/

--insert into Seg_Cliente
--select * from Cliente
--where dni like @dni

--delete from Cliente
--where dni like @dni

select* from CLiente
