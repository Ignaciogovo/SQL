Use Facturas

select distinct nombre from Producto

select distinct fabricacion from Producto


select distinct nombre,marca from Producto
order by marca


select distinct marca,nombre from Producto
order by marca

