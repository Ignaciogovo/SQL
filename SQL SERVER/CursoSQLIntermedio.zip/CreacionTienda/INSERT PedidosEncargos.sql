use Facturas

insert into Pedido
values
(CURRENT_TIMESTAMP,'111111111B')

select * from Pedido

insert into Encargo
values
(1,1,1,0)

select * from Encargo



---------------------------------------------
use Facturas

---- Pedidos de Clientes -----
insert into Pedido
values
('27/12/2019','333334444I')

insert into Pedido
values
('30/01/2020','666667777J')

insert into Pedido
values
('02/02/2020','444444444C')

insert into Pedido
values
('27/01/2020','333334444I')

insert into Pedido
values
('12/02/2020','777778888M')

insert into Pedido
values
('06/03/2020','777776666I')

insert into Pedido
values
('16/03/2020','888888888E')


----- Encargos a Almac�n -------
insert into Encargo
values
(2,3,2,0)

insert into Encargo
values
(2,4,1,10)

insert into Encargo
values
(3,24,2,0)

insert into Encargo
values
(4,5,1,0)

insert into Encargo
values
(5,10,2,25)

insert into Encargo
values
(5,15,3,0)

insert into Encargo
values
(5,9,1,15)

insert into Encargo
values
(6,11,2,12)

insert into Encargo
values
(7,18,1,0)

insert into Encargo
values
(8,28,1,0)

