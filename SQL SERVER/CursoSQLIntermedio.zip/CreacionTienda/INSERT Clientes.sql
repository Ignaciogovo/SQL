use Facturas

insert into Cliente
values
('123456789A','Carlos','carlos@sumail.com',23,'Calle Norte n� 1')

insert into Cliente
(dni,nombre)
values
('111111111B','Juan')


insert into Cliente
values
('222222222C','�scar','oscar@sumail.com',28,'Calle Sur n� 18')

insert into Cliente
values
('333333333C','Antonio','antonio@unmailmas.com',17,'Calle Oeste n� 21')

insert into Cliente
values
('444444444C','Jorge','jorge@sumail.com',36,'Calle mayor n� 5')

insert into Cliente
values
('555555555C','Jorge','jorge@otromail.com',27,'Calle menor n� 2 tercero')

insert into Cliente
values
('666666666C','Faustino','fa@sumail.com',47,'Avenida Principal n� 218')

insert into Cliente
values
('777777777D','Julio','julio@mejormail.com',26,'Calle del Poligono n� 26')

insert into Cliente
values
('888888888E','Susana','susan@susanmail.com',21,'Calle diagonal n� 82 A')

insert into Cliente
values
('999999999F','Esther','esther@thermail.com',28,'Calle Arriba n� 44 Segundo')

insert into Cliente
values
('111112222G','Sandra','sandra@mailsan.com',24,'Calle Abajo n� 18')

insert into Cliente
values
('222223333H','Silvia','silvia@mejormail.com',22,'Calle Sur n� 78 Cuarto')

insert into Cliente
values
('333334444I','Cristina','cris@mejormail.com',32,'Calle Abajo n� 2 Bajo')

insert into Cliente
values
('444455555I','Bea','bea@sumail.com',52,'Calle Abajo n� 31')

insert into Cliente
values
('555556666I','Yolanda','yoli@masmail.com',46,'Avenida extraradio n� 4')

insert into Cliente
values
('666667777J','Alicia','Ali@otromail.com',42,'Plaza Cuadrada n� 1')

insert into Cliente
values
('777776666I','Mar','mar@mejormail.com',18,'Calle diagonal n� 14 B')

insert into Cliente
values
('777778888M','Noelia','noe@otromailmas.com',52,'Calle monta�a n� 2')

insert into Cliente
(dni,nombre,email)
values
('888889999X','Lucas P�rez','lucas.perez@masmail.com')

insert into Cliente
values
('999900000Y','Santi Santos','santos.santi@gmail.com',47,'13,Rue del Percebe')

select * from Cliente

select 'Para los que no lo conozcais, buscad "13, Rue del Percebe" en Google'







