Use Facturas

backup database Facturas
to disk = 'd:\programas\facturas.bak'
with format,
	medianame = 'CopiaFacturas',
	name = 'Copia de Facturas'