Use master

restore database Facturas
	from disk = 'd:\programas\facturas.bak'